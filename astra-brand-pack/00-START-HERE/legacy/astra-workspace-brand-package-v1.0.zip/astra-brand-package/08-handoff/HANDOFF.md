# Astra Workspace Brand Handoff

## Included
- Canonical brand guidelines
- Primary logo SVG
- Symbol SVG
- Monochrome symbol variants
- Raster symbol PNGs
- App icons + favicon
- CSS design tokens
- JSON design tokens
- Tailwind token module
- UI canonicals
- Visual prompt snippets
- Approved mockup references (where available)
- Asset manifest

## Implementation rules
- Do not change the Astra name, logo silhouette, or palette without a canonical brand revision.
- Provider/model/runtime state must be real, not decorative.
- Dark and light modes share the same hierarchy.
- Green indicates selected / healthy / live state.
- Violet remains secondary.
- Do not drift into generic navy SaaS styling.
- Do not expose secrets in UI, client bundles, telemetry, or logs.
