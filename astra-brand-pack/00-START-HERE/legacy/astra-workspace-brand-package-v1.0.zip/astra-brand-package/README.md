# Astra Workspace — Brand Package v1.0

This package contains the canonical Astra Workspace visual identity, design tokens, vector/raster logo assets, UI canonicals, mockup references, visual-generation prompts, and implementation handoff rules.

Start here:
1. `01-brand-guidelines/ASTRA-BRAND-GUIDELINES.md`
2. `05-ui-canonicals/ASTRA-UI-CANONICALS.md`
3. `04-design-tokens/`
4. `08-handoff/HANDOFF.md`

The package is intended for frontend implementation, product design, AI-assisted generation, documentation, investor/demo materials, and external developer handoff.
