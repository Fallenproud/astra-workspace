# Astra Workspace — UI Canonicals

1. **App Shell** — persistent desktop-first three-zone shell.
2. **Left Navigation** — Workspace, Projects, Runs, Artifacts, Integrations, Tools, Context Library, Settings.
3. **Runtime Control Bar** — Provider, Model, Reasoning, Compute Mode, Status, Context.
4. **Main Workspace** — task + conversation + execution.
5. **Execution Blocks** — plans, tests, tools, errors, artifacts as inspectable structured units.
6. **Composer** — prompt, files, tools, search, modes, submit/cancel.
7. **Runtime Inspector** — Run / Context / Files / Tools tabs with real telemetry.
8. **Persistence Model** — Project → Workspace/Task → Run → Events/Steps → Artifacts.
9. **Artifact + Tool System** — generated outputs and tools are first-class, persistent objects.
10. **Visual Language** — obsidian/graphite + emerald/violet, thin borders, restrained glow, truthful state.
