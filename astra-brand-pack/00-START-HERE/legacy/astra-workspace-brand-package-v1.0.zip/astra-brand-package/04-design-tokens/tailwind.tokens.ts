// Astra Workspace canonical tokens
export const astra = {
  colors: {
    emerald: '#22E6A8',
    emeraldDeep: '#0FBF84',
    violet: '#8A5CF6',
    cyan: '#3FD5E3',
    obsidian: '#071013',
    graphite: '#0D171C',
    panel: '#101D23',
    border: '#223139',
    ice: '#EAF7F4',
    silver: '#B9C7C8',
  },
  fonts: {
    sans: ['Geist', 'Inter', 'system-ui', 'sans-serif'],
    mono: ['JetBrains Mono', 'IBM Plex Mono', 'monospace'],
  },
}
