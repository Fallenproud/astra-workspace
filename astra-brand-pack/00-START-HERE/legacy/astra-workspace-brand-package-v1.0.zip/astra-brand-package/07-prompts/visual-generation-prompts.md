# Astra Workspace — Brand Prompt Snippets

## Product mockup
Create a premium Astra Workspace desktop AI control-plane interface using the canonical dark theme: obsidian / graphite surfaces, restrained emerald active states, secondary ultraviolet-violet accents, thin glassy borders, crisp Geist-like typography, and real operational telemetry. Use a persistent left navigation, central work surface, runtime control bar, and right inspector.

## Marketing landing page
Create a polished Astra Workspace launch page using the canonical identity. Hero message: “Connect models. Run AI work. Keep everything in one place.” Include product preview, provider/model activation, secure API key setup, projects/runs, context+compute governance, artifacts/tools, observability, integrations, and an end-to-end CTA.

## Light mode
Preserve Astra emerald and violet identity while moving to pearl-white, soft silver, pale mint, low-shadow surfaces with excellent information density and accessibility.

## AIKOV-inspired environmental edition
Use a cinematic aurora night environment with emerald and ultraviolet lighting behind translucent obsidian UI. Maintain Astra brand identity and product hierarchy; adapt only the environmental / glass treatment.
