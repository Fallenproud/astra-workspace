# ASTRA WORKSPACE — CANONICAL BRAND SYSTEM v1.0

## Brand Core

**Name:** Astra Workspace  
**Primary descriptor:** AI Workspace / AI Agent Platform / Multi-Model AI Control Plane  
**Purpose:** Give Astra and connected AI models a persistent, observable, extensible place to do real work end-to-end — not merely chat.

### Product promise
**Connect models. Run AI work. Keep everything in one place.**

### Brand character
- Precise
- Sophisticated
- Capable
- Operational
- Calm under complexity
- Technical without becoming cold
- Futuristic without becoming ornamental

### Canonical product sentence
Astra Workspace is a production-oriented AI workspace where users connect model providers, securely manage API keys, run real tasks, inspect execution, manage projects and artifacts, control context and compute, and keep work persistent across sessions.

---

# Visual Identity

## Canonical direction
Astra uses a premium obsidian / graphite base with restrained luminous emerald accents and a secondary ultraviolet-violet layer.

The visual language is derived from:
- high-end developer tooling
- desktop operating environments
- transparent operational telemetry
- crystalline / aurora lighting
- restrained glassmorphism
- dense but calm information hierarchy

## Core palette

### Primary
- Astra Emerald — `#22E6A8`
- Astra Deep Emerald — `#0FBF84`
- Astra Obsidian — `#071013`
- Astra Graphite — `#0D171C`
- Astra Panel — `#101D23`
- Astra Border — `#223139`

### Secondary
- Astra Violet — `#8A5CF6`
- Astra Aurora Cyan — `#3FD5E3`
- Astra Ice — `#EAF7F4`
- Astra Silver — `#B9C7C8`

### Functional
- Success — `#22E6A8`
- Warning — `#F2C94C`
- Error — `#FF6B6B`
- Info — `#3FD5E3`

## Light mode
- Background — `#F7FBFA`
- Surface — `#FFFFFF`
- Soft Surface — `#EFF7F5`
- Border — `#D9E7E3`
- Text Primary — `#101820`
- Text Secondary — `#5E6B72`

## Gradients
**Aurora Brand Gradient**
`linear-gradient(135deg, #22E6A8 0%, #3FD5E3 45%, #8A5CF6 100%)`

**Dark Surface Glow**
`radial-gradient(circle at top left, rgba(34,230,168,.18), transparent 45%)`

---

# Typography

Preferred UI typography:
- **Primary UI:** Geist
- **Alternative / Brand display:** Aeonik Pro
- **Data / telemetry:** IBM Plex Mono
- **Code:** JetBrains Mono

Rules:
- Avoid excessive display typography inside operational UI.
- Use strong weight contrast instead of oversized headings.
- Monospace is reserved for code, tokens, IDs, metrics, terminal output, and machine state.

---

# Logo System

## Canonical mark
The Astra mark is a faceted triangular “A” / prism form.

It should communicate:
- upward motion
- intelligence
- crystalline structure
- modularity
- precision
- system-level control

## Logo treatments
1. Full color aurora gradient
2. Emerald monochrome
3. White monochrome
4. Black monochrome
5. App icon / symbol only
6. Horizontal lockup: symbol + ASTRA WORKSPACE

Do not:
- stretch the mark
- add heavy drop shadows
- rotate it arbitrarily
- introduce unrelated colors
- place detailed textures inside the mark
- replace the triangular silhouette with a generic letter A

---

# UI Canonical Hierarchy

1. App Shell
2. Left Navigation
3. Runtime Control Bar
4. Main Workspace
5. Execution Blocks
6. Composer / Command Surface
7. Right Runtime Inspector
8. Projects / Runs / Persistence
9. Artifact + Tool System
10. Visual + Interaction Language

The shell remains persistent while operational surfaces evolve.

---

# Dark Mode Canon

- Obsidian background
- Graphite layered panels
- Emerald for selected / healthy / live state
- Violet only as a secondary accent
- Thin borders
- Subtle luminous edge treatment
- No generic blue SaaS palette
- No decorative gradients that imply fake state

# Light Mode Canon

- White / pearl / soft silver
- Pale mint support surfaces
- Emerald remains the primary interaction color
- Shadows should be restrained
- Dense operational UI must remain readable
- Do not convert the product into a generic consumer dashboard

---

# Motion

Motion should be finite, restrained, and semantic.

Approved motion classes:
- status pulse
- tool activity
- timeline progression
- subtle aurora background drift
- panel focus / expansion
- success confirmation
- loading progress

Avoid:
- constant gratuitous neon motion
- looping animations that distract from execution
- large parallax in core operational workspace

---

# Voice & Copy

Astra copy is:
- concise
- technical when necessary
- direct
- human-readable
- never hype-first inside the product

Good:
- “Running tests”
- “Waiting for approval”
- “OpenAI connected”
- “Context compacted”
- “3 artifacts created”

Avoid:
- “Magic happened”
- “Supercharge everything”
- “AI-powered awesomeness”

---

# Brand / Product Separation

Canonical:
- Astra identity
- color system
- logo family
- typography direction
- runtime/control-plane separation
- observability
- truthful state
- compute/context governor principles

Evolving:
- exact navigation
- panel arrangement
- module count
- inspector details
- workflow layouts
- future integrations
- agent-specific surfaces

---

# Handoff Rule

The brand package is authoritative for identity and frontend visual direction.
Implementation may evolve functionally, but brand identity must not drift without an explicit canonical brand revision.
